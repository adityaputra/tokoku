Charisma
========
[![Flattr this](http://api.flattr.com/button/flattr-badge-large.png "Flattr this")](http://flattr.com/thing/1507720/usmanhalalitcharisma-on-GitHub)


#### free, premium quality, responsive, multiple skin admin template.

I have created Charisma to ease the repeat work I have to do on my projects. Now I re-use Charisma as a base for my admin panel work and I am sharing it with you :)

[**See Live Demo**](http://usman.it/themes/charisma/ "")

Please visit [http://usman.it/free-responsive-admin-template/](http://usman.it/free-responsive-admin-template/ "") for more information.


[![Bitdeli Badge](https://d2weczhvl823v0.cloudfront.net/usmanhalalit/charisma/trend.png)](https://bitdeli.com/free "Bitdeli Badge")

